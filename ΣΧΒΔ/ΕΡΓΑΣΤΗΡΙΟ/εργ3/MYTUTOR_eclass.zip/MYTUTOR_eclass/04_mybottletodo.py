from bottle import route, run
import sys, os 
import pymysql

connection = pymysql.connect(host='localhost',
                             user='root',  # use your own user
                             password='sasa', # use your own password
                             database='labtest') # use your own test database schema

@route('/todo')
def todo():
    # prepare a cursor object using cursor() method
    cursor = connection.cursor()
    cursor.execute("SELECT task FROM todo WHERE status LIKE '1'")
    result = cursor.fetchall()
    print(result)
    return str(result)

#add this at the very end: By enabling debug, you will get a full stacktrace of the Python interpreter, which usually contains useful information for finding bugs.

run(host='localhost', port=8080, debug=True)
