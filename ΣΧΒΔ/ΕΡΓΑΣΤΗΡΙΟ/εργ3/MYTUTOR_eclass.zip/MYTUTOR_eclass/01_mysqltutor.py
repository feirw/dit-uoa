import sys, os
import pymysql

#######ex. 1
# Open database connection
connection = pymysql.connect(host='localhost',
                             user='root',  # use your own user
                             password='sasa', # use your own password
                             database='labtest') # use your own test database schema

# prepare a cursor object using cursor() method
cursor = connection.cursor()

# execute SQL query using execute() method.
cursor.execute("SELECT VERSION()")

# Fetch a single row using fetchone() method.
data = cursor.fetchone()
print ("Database version : %s " % data)

# disconnect the Database connection
connection.close()

#######ex. 2

## Open database connection
# connection = pymysql.connect(host='localhost',
#                             user='root',
#                             password='sasa',
#                             database='lab3db')
#
# prepare a cursor object using cursor() method
# cursor = connection.cursor()

# Drop table if it already exist using execute() method.
# cursor.execute("DROP TABLE IF EXISTS EMPLOYEE")

# Create table as per requirement
# sql = """CREATE TABLE EMPLOYEE (
#   FIRST_NAME  CHAR(20) NOT NULL,
#   LAST_NAME  CHAR(20),
#   AGE INT,
#   SEX CHAR(1),
 #  INCOME FLOAT )"""

# cursor.execute(sql)

# sqlQuery  = "show tables"

# cursor.execute(sqlQuery)
#Fetch all the rows
# rows = cursor.fetchall()
# for row in rows:
#	print(row)

# ###################################################################################################
# # Prepare SQL query to INSERT a record into the database.
# sql = """INSERT INTO EMPLOYEE(FIRST_NAME,
   # LAST_NAME, AGE, SEX, INCOME)
   # VALUES ('Mac', 'Mohan', 20, 'M', 2000)"""
# try:
   # # Execute the SQL command
   # cursor.execute(sql)
   # # Commit your changes in the database
   # connection.commit()
# except:
   # # Rollback in case there is any error
   # connection.rollback()
# try:
    # connection.commit()
# except:
    # connection.rollback()

# #########################################################################################################

# # Prepare SQL query to READ a record from the database.
# sql = "SELECT * FROM EMPLOYEE WHERE INCOME > '%d'" % (1000)
# try:
   # # Execute the SQL command
   # cursor.execute(sql)
# except:
   # print ("Error: unable to fetch data")

# # Fetch all the rows in a list of lists.
# results = cursor.fetchall()
# for row in results:
   # fname = row[0]
   # lname = row[1]
   # age = row[2]
   # sex = row[3]
   # income = row[4]
   # # Now print fetched result
   # print ("fname = %s,lname = %s,age = %d,sex = %s,income = %d" % \
          # (fname, lname, age, sex, income ))

# #######################################################################################################
# ###########Prepare SQL query to UPDATE required records
# sql = "UPDATE EMPLOYEE SET AGE = AGE + 1 WHERE SEX = '%c'" % ('M')
# try:
   # # Execute the SQL command
   # cursor.execute(sql)

# except:
   # # Rollback in case there is any error
   # connection.rollback()

# # Commit your changes in the database
# connection.commit()


# sql = "SELECT * FROM EMPLOYEE"
# cursor.execute(sql)
# results = cursor.fetchall()
# for row in results:
      # fname = row[0]
      # lname = row[1]
      # age = row[2]
      # sex = row[3]
      # income = row[4]
      # # Now print fetched result
      # print ("fname = %s,lname = %s,age = %d,sex = %s,income = %d" % \
             # (fname, lname, age, sex, income ))


# # disconnect from server
# connection.close()
