import sys, os
from bottle import route, run
import pymysql

connection = pymysql.connect(host='localhost',
                             user='root',  # use your own user
                             password='sasa', # use your own password
                             database='labtest') # use your own test database schema

# prepare a cursor object using cursor() method
cursor = connection.cursor()

cursor.execute("DROP TABLE IF EXISTS todo")
sql = """CREATE TABLE todo (
   task char(100) NOT NULL,
   status bool NOT NULL 
)"""

cursor.execute(sql)

cursor.execute("INSERT INTO todo (task,status) VALUES ('Read A-byte-of-python to get a good introduction into Python',0)")
cursor.execute("INSERT INTO todo (task,status) VALUES ('Visit the Python website',1)")
cursor.execute("INSERT INTO todo (task,status) VALUES ('Test various editors for and check the syntax highlighting',1)")
cursor.execute("INSERT INTO todo (task,status) VALUES ('Choose your favorite WSGI-Framework',0)")

connection.commit()


